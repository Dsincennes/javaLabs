import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * CET - CS Academic Level 3
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * This class contains the dynamically allocated array and it's processing
 * Student Name: Donald Sincennes 
 * Student Number: 41011305 
 * Section Number: 304
 * Course: CST8130 - Data Structures
 * Professor: James Mwangi PhD.
 * @author Donald Sincennes
 */
public class Lab1 {
	// constants for menu
	private static final int INIT = 1;
	private static final int ARRAYSIZE = 2;
	private static final int ADDTOARRAY = 3;
	private static final int ARRAYCONTENT = 4;
	private static final int DISPLAY = 5;
	private static final int EXIT = 6;

	/**
	 * Main method, drives the program, Calls display Menu method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		displayMainMenu();
	} // End main
	
	// menu method, allows user to select from all methods created in Numbers class.
	/**
	 * Method holds menu, and will do what a user asks by creating an object of type Numbers, 
	 * and will call a method based on input
	 */
	public static void displayMainMenu() {
		boolean exit = false;
		Scanner keyboard = new Scanner(System.in);
		int size;
		Numbers num = new Numbers();
		
		do {
			try {
				System.out.println();
				System.out.println("Please select one of the following:");
				System.out.println("1: Initialize a default array");
				System.out.println("2: To specify the max size of the array");
				System.out.println("3: Add value to the array");
				System.out.println("4: Display values in the array");
				System.out.println("5: Display the average of the values");
				System.out.println("6: To Exit");
				System.out.print("> ");

				int choice = keyboard.nextInt();

				switch (choice) {
				case INIT: // Initializes Default Array
					num = new Numbers();
					break;
				case ARRAYSIZE: // Allows user to input size of Array
					while (true) {
						try {
							System.out.print("Enter new size of array: ");
							size = keyboard.nextInt();
							while (size <= 0) {
								System.out.print("Please enter positive Number: ");
								size = keyboard.nextInt();
							}
							num = new Numbers(size);
						} catch (InputMismatchException e) {
							System.err.print("Input Mismatch while reading size\n");
							keyboard.nextLine();
						}
						break;
					}
					break;
				case ADDTOARRAY: // Adds values to Array
					num.addValue(keyboard);
					break;

				case ARRAYCONTENT: // Prints contents inside array
					System.out.print("Numbers are: \n" + num);
					break;

				case DISPLAY: // Displays Min, Max and Average of all values inside array
					num.minMax();
					break;

				case EXIT: // EXIT PROGRAM
					System.out.println("Exiting..."); // exits
					exit = true;
					break;

				default: // DEFAULT FOR WRONG ENTRY
					System.out.println("Invalid Entry, Select 1-6... Please try again!");
					break;
				}
			} catch (InputMismatchException e) {
				System.err.print(
						"Input mismatch Exception while reading user's choice in main menu... please try again!\n");
				keyboard.nextLine();
			}

		} while (!exit); // Control variable for loop
	}

} // End Class
