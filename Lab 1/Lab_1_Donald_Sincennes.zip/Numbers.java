import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * CET - CS Academic Level 3
 * Declaration: I declare that this is my own original work and is free from Plagiarism
 * This class contains main method that drives the program.
 * Student Name: Donald Sincennes 
 * Student Number: 41011305 
 * Section Number: 304
 * Course: CST8130 - Data Structures
 * Professor: James Mwangi PhD.
 * @author Donald Sincennes
 */
public class Numbers {
	/**
	 * Stores Float values.
	 */
	private Float[] numbers;

	/**
	 * Store the number of items currently in the array.
	 */
	private int numItems;

	/**
	 * Default Constructor, initializes a default array of size 10
	 */
	public Numbers() {	// default constructor
		numbers = new Float[10];
//		for(int i = 0; i < numbers.length; i++) { // Setting all elements of array to zero.
//			numbers[i] = 0.0f;
//		}
		Arrays.fill(numbers, 0.0f);
	}

	/**
	 * Constructor that initializes the numbers array.
	 * 
	 * @param size - Max size of the numbers array
	 */
	public Numbers(int size) {
		numbers = new Float[size];
//		for(int i = 0; i < numbers.length; i++) { // Setting all elements of array to zero.
//			numbers[i] = 0.0f;
//		}
        Arrays.fill(numbers, 0.0f);
	}

	/**
	 * Adds a value in the array
	 * 
	 * @param keyboard - Scanner object to use for input
	 */
	public void addValue(Scanner keyboard) {
			try {
				if (numItems < numbers.length) { // checks to make sure array isn't full of values
					System.out.print("Enter Value: ");
					numbers[numItems] = keyboard.nextFloat();
					numItems++;
				} else {
					System.out.println("Array Full");
				}
			} catch (InputMismatchException e) {
				System.err.println("input mismatch while adding values");
				keyboard.next();
			}
		}


	// Method Calculates average of values inputted into a numbers array
	/**
	 * Calculates the average of all the values in the numbers array.
	 * 
	 * @return float value that represents the average
	 */
	public float calcAverage() {
		if(numItems == 0) { // checking for empty Array, return 0 if so.
			return 0;
		}
		float avg = 0.0f;
		for (int i = 0; i < numItems; i++) { // Adds values of all elements in the array.
			avg += numbers[i];
		}
		return avg /= numItems;
	}

	// Method goes through array, and finds the min and max values input by the user. 
	// Also calls calcAverage method and prints all values
	/**
	 * Method finds smallest and max value inside an array. As well calls the CalcAverage() method.
	 * 
	 */
	public void minMax() {
		float max = numbers[0];
		float min = numbers[0];

		if(numItems > 0) {
			for (int i = 0; i < numItems; i++) { 	// goes through number of items in array, checks each index starting from 0 to
													// see if it greater than the next. If it is greater, it gets set it to max.
													// Same for min.
				if (numbers[i] > max) {
					max = numbers[i];
				}
				if (numbers[i] < min) {
					min = numbers[i];
				}
			}
		}
		System.out.printf("Average is: %.2f Minimum Value: %.1f Maximum Value: %.1f \n", calcAverage(), min, max);
	}

	// Overriding toString to for printing elements inside array.
	@Override
	public String toString() {
		String text = "";
		for (int i = 0; i < numItems; i++) { // Goes through entire array and prints each index for the amount of items in the array.
			text = text.concat(numbers[i].toString() + "\n");
		}
		return text;
	}

}
